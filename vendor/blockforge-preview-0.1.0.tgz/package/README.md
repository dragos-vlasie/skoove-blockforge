# BlockForge preview interactions 0.1.0

Shared React controls and preview bridge protocol v4. This package contains no
CMS persistence, credentials, site templates or database code. It is not yet
published to an npm registry.

## Integration

- Managed previews use `SectionToolbar` and `SectionInsertionBoundary` directly.
- Dedicated client previews mount `PreviewOverlay` as a **sibling** of the site's
  content root. Keep the public renderer memoized; hover/geometry state belongs
  only to the overlay. `src/next/LivePreviewClient.tsx` is the reference adapter.
- Pass the page's own section IDs/types, current selection and a document key.
  Each rendered section must expose `data-blockforge-block-id`. Descendants of
  compositions/shared references resolve to their owning page section. Child
  editing remains in the existing sidebar; page actions never mutate a shared
  source or guess which nested container to alter.
- Transport action intents, never content mutations. Check frame source, exact
  origin, document ID, route path, action allowlist and section membership in the
  host. The CMS owns persistence, selection and structural undo.
- In Tailwind v4, explicitly include this package's sources in the consuming
  stylesheet: `@source "../node_modules/@blockforge/preview/src";` (adjust the
  relative path to the stylesheet). The monorepo already scans `packages`.
- Consumers need React 18/19 and a TS/TSX-capable bundler. No new database tables,
  migrations, public-site scripts or server secrets are required.

## Controlled distribution

Use `npm pack ./packages/preview` to create the versioned artifact, then install
that artifact in a client repository and import from `@blockforge/preview`.
Do not copy and maintain separate control implementations. Release/pin a new
package version for future client upgrades. Publishing and deployment are
separate explicit release steps; changing the CMS does not update client builds.

Deploy the CMS host first. v2/v3 clients retain the old subject updates/insertion
behaviour and visible sidebar controls; the CMS reports missing capabilities.
Then deploy one client with the package, adapter and Tailwind source inclusion.
Only show section-action controls after the host advertises `section-actions` in
its render handshake. Verify the host reports both insertion and section actions
before rolling out the same artifact to other clients.

## Acceptance checks

1. Hover shows a label/outline without changing sidebar selection or rendering
   the site again. Click/tap/Enter selects the owning section.
2. Insertion lines span the section, track resize/scroll/image loading, and never
   represent an offscreen boundary as a viewport-edge insertion point.
3. Up/down, duplicate, remove, add-before/after and empty-page insertion work.
   Undo move/remove/duplicate preserves unrelated field edits. It is structural
   undo (last 30 actions), not global text undo/redo or editor navigation history.
4. Keyboard toolbar navigation skips disabled actions; Escape dismisses controls
   and restores focus. Sidebar actions remain available at all screen sizes.
5. Browse mode stops intercepting site interactions. The managed CMS switches to
   its public renderer; dedicated clients keep their existing renderer. Remote
   navigation links open in a new tab to keep the preview bridge connected.
6. Reject stale-page, unknown-action and nested-child mutation messages.

Local checks:

```
node --import tsx --test tests/preview-interactions.test.ts
node --test tests/preview-overlay.browser.test.mjs
npm run typecheck -- --incremental false
```

Browser checks use only an in-memory fixture and localhost, never production
content. Field-level remote inspection and freeform canvas dragging are later
capabilities; the sidebar remains the precise nested-editing/reordering surface.
