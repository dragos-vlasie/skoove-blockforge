"use client";

import { useRef, useState } from "react";
import type { SectionAction } from "./protocol";

const buttonClass = "inline-flex min-h-8 shrink-0 items-center justify-center rounded-md px-2 text-xs font-semibold text-slate-700 hover:bg-violet-50 hover:text-violet-700 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-500 disabled:cursor-not-allowed disabled:opacity-35";

export function SectionToolbar({ label, isFirst, isLast, onAction, onDismiss }: {
  label: string;
  isFirst: boolean;
  isLast: boolean;
  onAction: (action: SectionAction) => void;
  onDismiss?: () => void;
}) {
  const [expanded, setExpanded] = useState(false);
  const [tabIndex, setTabIndex] = useState(0);
  const toolbarRef = useRef<HTMLDivElement>(null);
  const actions: Array<{ action: SectionAction; label: string; text: string; disabled?: boolean }> = [
    { action: "edit", label: "Edit section fields", text: "Edit" },
    { action: "move-up", label: "Move section up", text: "↑", disabled: isFirst },
    { action: "move-down", label: "Move section down", text: "↓", disabled: isLast },
    { action: "duplicate", label: "Duplicate section", text: "Duplicate" },
  ];
  const focusIndex = actions[tabIndex]?.disabled ? 0 : tabIndex;
  return (
    <div data-blockforge-preview-control data-cms-inspector-control className="max-w-full rounded-lg border border-violet-200 bg-white p-1 text-slate-900 shadow-lg shadow-slate-950/10" onClick={(event) => event.stopPropagation()}>
      <div ref={toolbarRef} role="toolbar" aria-label={`${label} section actions`} className="flex max-w-full items-center gap-0.5 overflow-x-auto"
        onKeyDown={(event) => {
          if (event.key === "Escape") { setExpanded(false); onDismiss?.(); return; }
          if (!["ArrowLeft", "ArrowRight", "Home", "End"].includes(event.key)) return;
          event.preventDefault();
          const buttons = Array.from(event.currentTarget.querySelectorAll<HTMLButtonElement>("button:not(:disabled)"));
          const current = buttons.indexOf(event.target as HTMLButtonElement);
          const next = event.key === "Home" ? 0 : event.key === "End" ? buttons.length - 1
            : (current + (event.key === "ArrowRight" ? 1 : -1) + buttons.length) % buttons.length;
          buttons[next]?.focus();
        }}>
        <span className="hidden max-w-40 truncate px-2 text-xs font-bold text-violet-700 sm:inline">{label}</span>
        {actions.map((item, index) => <button key={item.action} type="button" className={buttonClass} title={item.label} aria-label={item.label}
          disabled={item.disabled} tabIndex={focusIndex === index ? 0 : -1} onFocus={() => setTabIndex(index)} onClick={() => onAction(item.action)}>{item.text}</button>)}
        <button type="button" className={buttonClass} aria-label="More section actions" title="More section actions" aria-expanded={expanded}
          tabIndex={focusIndex === actions.length ? 0 : -1} onFocus={() => setTabIndex(actions.length)} onClick={() => setExpanded(!expanded)}>•••</button>
      </div>
      {expanded && <div className="mt-1 flex flex-wrap gap-1 border-t border-slate-200 pt-1" onKeyDown={(event) => {
        if (event.key === "Escape") { event.stopPropagation(); setExpanded(false); toolbarRef.current?.querySelector<HTMLButtonElement>("[aria-expanded]")?.focus(); }
      }}>
        {([ ["insert-before", "Add before"], ["insert-after", "Add after"], ["remove", "Remove section"] ] as const).map(([action, text]) =>
          <button type="button" key={action} className={`${buttonClass} ${action === "remove" ? "text-rose-700" : ""}`} onClick={() => {
            setExpanded(false);
            toolbarRef.current?.querySelector<HTMLButtonElement>("[aria-expanded]")?.focus();
            onAction(action);
          }}>{text}</button>)}
        {label.startsWith("Shared section") && <p className="w-full px-2 py-1 text-xs text-slate-500">Remove affects this instance, not the shared source.</p>}
      </div>}
    </div>
  );
}

export function SectionInsertionBoundary({ label, onInsert }: { label: string; onInsert: () => void }) {
  return <div data-blockforge-preview-control className="flex w-full items-center gap-2" onClick={(event) => event.stopPropagation()}>
    <span aria-hidden="true" className="h-px min-w-0 flex-1 bg-violet-400" />
    <button type="button" title={label} aria-label={label} onClick={onInsert}
      className="inline-flex min-h-8 shrink-0 items-center gap-1.5 rounded-full border border-violet-400 bg-white px-3 text-xs font-bold text-violet-700 shadow-sm hover:bg-violet-50 focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-violet-200">
      <span aria-hidden="true">+</span> Add section
    </button>
    <span aria-hidden="true" className="h-px min-w-0 flex-1 bg-violet-400" />
  </div>;
}
