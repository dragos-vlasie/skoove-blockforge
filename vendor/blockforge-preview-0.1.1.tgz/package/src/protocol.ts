export const previewMessageType = {
  ready: "blockforge:preview:ready",
  render: "blockforge:preview:render",
  updateSubject: "blockforge:preview:update-subject",
  setActiveBlock: "blockforge:preview:set-active-block",
  selectBlock: "blockforge:preview:select-block",
  requestSectionInsert: "blockforge:preview:request-section-insert",
  sectionAction: "blockforge:preview:section-action",
  scroll: "blockforge:preview:scroll",
  scrollTo: "blockforge:preview:scroll-to",
  scrollToElement: "blockforge:preview:scroll-to-element",
} as const;

export const previewProtocolVersion = 4;

export const previewCapability = {
  subjectUpdates: "subject-updates",
  sectionInsertion: "section-insertion",
  sectionActions: "section-actions",
} as const;

export type PreviewCapability = typeof previewCapability[keyof typeof previewCapability];

export type RemotePreviewRoute = {
  graph: any;
  subject: any;
  routeType: "page" | "entry";
  path: string;
  page?: number;
  collection?: any;
};

export type ParentToPreviewMessage =
  | { type: typeof previewMessageType.render; route: RemotePreviewRoute; activeBlockId?: string | null; capabilities?: PreviewCapability[] }
  | { type: typeof previewMessageType.updateSubject; subject: any }
  | { type: typeof previewMessageType.setActiveBlock; activeBlockId?: string | null }
  | { type: typeof previewMessageType.scrollTo; position: { x: number; y: number } }
  | { type: typeof previewMessageType.scrollToElement; attribute: string; value: string };

export type PreviewToParentMessage =
  | { type: typeof previewMessageType.ready; protocolVersion?: number; capabilities?: PreviewCapability[]; contentCapabilities?: string[] }
  | ({ type: typeof previewMessageType.selectBlock; blockId: string } & Partial<PreviewScope>)
  | ({ type: typeof previewMessageType.requestSectionInsert; afterBlockId?: string; atIndex?: number } & Partial<PreviewScope>)
  | ({ type: typeof previewMessageType.sectionAction } & SectionActionRequest)
  | { type: typeof previewMessageType.scroll; position: { x: number; y: number } };

export const isPreviewMessage = (value: unknown): value is { type: string } =>
  Boolean(value && typeof value === "object" && typeof (value as { type?: unknown }).type === "string");

export const sectionActions = ["edit", "move-up", "move-down", "duplicate", "remove", "insert-before", "insert-after"] as const;
export type SectionAction = typeof sectionActions[number];
export type PreviewSection = { id: string; type: string };
export type PreviewScope = { subjectId: string; path: string };
export type SectionActionRequest = PreviewScope & { blockId: string; action: SectionAction };

export function matchesPreviewScope(request: Partial<PreviewScope>, scope: PreviewScope, allowLegacy = false) {
  if (request.subjectId === undefined && request.path === undefined) return allowLegacy;
  return request.subjectId === scope.subjectId && request.path === scope.path;
}

export function resolveSectionInsertion(request: { afterBlockId?: unknown; atIndex?: unknown }, sections: PreviewSection[]) {
  if (typeof request.afterBlockId === "string") {
    return request.atIndex === undefined && sections.some((section) => section.id === request.afterBlockId)
      ? { afterBlockId: request.afterBlockId } : null;
  }
  return request.afterBlockId === undefined && typeof request.atIndex === "number"
    && Number.isInteger(request.atIndex) && request.atIndex >= 0 && request.atIndex <= sections.length
    ? { atIndex: request.atIndex } : null;
}

// Only page-owned sections may be mutated by the page-level action handlers.
export function isSectionActionRequest(value: unknown, scope: PreviewScope, sections: PreviewSection[]): value is SectionActionRequest {
  if (!value || typeof value !== "object") return false;
  const request = value as Record<string, unknown>;
  return request.subjectId === scope.subjectId && request.path === scope.path
    && typeof request.blockId === "string" && sections.some((section) => section.id === request.blockId)
    && sectionActions.includes(request.action as SectionAction);
}

export function sectionLabel(section: PreviewSection) {
  if (section.type === "SHARED_BLOCK") return "Shared section · instance";
  return section.type.replace(/[_-]/g, " ").toLowerCase().replace(/^./, (letter) => letter.toUpperCase());
}
