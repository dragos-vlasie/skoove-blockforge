"use client";

import { useEffect, useRef, useState, type RefObject } from "react";
import { SectionInsertionBoundary, SectionToolbar } from "./SectionControls";
import { sectionLabel, type PreviewSection, type SectionAction } from "./protocol";

type Box = { id: string; left: number; top: number; width: number; height: number };
type Geometry = { selected: Box | null; hovered: Box | null; boundary: (Box & { before: boolean }) | null };
const emptyGeometry: Geometry = { selected: null, hovered: null, boundary: null };

export function findOwningSection(target: Element | null, root: HTMLElement, ids: Set<string>): HTMLElement | null {
  let owner: HTMLElement | null = null;
  for (let element = target; element && element !== root; element = element.parentElement) {
    const id = element.getAttribute("data-blockforge-block-id");
    if (id && ids.has(id)) owner = element as HTMLElement;
  }
  return owner;
}

/** Sibling overlay: pointer/geometry updates never render the site's content tree. */
export function PreviewOverlay({ rootRef, sections, activeBlockId, documentKey, canAct, onSelect, onAction, onInsert }: {
  rootRef: RefObject<HTMLDivElement | null>;
  sections: PreviewSection[];
  activeBlockId: string | null;
  documentKey: string;
  canAct: boolean;
  onSelect: (id: string) => void;
  onAction: (id: string, action: SectionAction) => void;
  onInsert: (options: { afterBlockId?: string; atIndex?: number }) => void;
}) {
  const [browsing, setBrowsing] = useState(false);
  const [geometry, setGeometry] = useState<Geometry>(emptyGeometry);
  const [dismissed, setDismissed] = useState(false);
  const hoveredRef = useRef<{ id: string; before: boolean } | null>(null);
  const previousOrderRef = useRef<string | null>(null);
  const callbacks = useRef({ onSelect, onAction, onInsert });
  callbacks.current = { onSelect, onAction, onInsert };
  const sectionKey = JSON.stringify(sections.map(({ id, type }) => [id, type]));

  useEffect(() => { setDismissed(false); hoveredRef.current = null; }, [documentKey, activeBlockId]);

  useEffect(() => {
    const root = rootRef.current;
    if (!root) return;
    const previous = root.getAttribute("data-blockforge-editing");
    root.setAttribute("data-blockforge-editing", String(!browsing));
    return () => {
      if (previous === null) root.removeAttribute("data-blockforge-editing");
      else root.setAttribute("data-blockforge-editing", previous);
    };
  }, [rootRef, documentKey, browsing]);

  useEffect(() => {
    const root = rootRef.current;
    if (!root) { setGeometry(emptyGeometry); return; }
    const doc = root.ownerDocument;
    const win = doc.defaultView!;
    if (browsing) {
      setGeometry(emptyGeometry);
      const openLink = (event: MouseEvent) => {
        const anchor = (event.target as Element).closest<HTMLAnchorElement>("a[href]");
        if (!anchor || anchor.hasAttribute("download")) return;
        const destination = new URL(anchor.href, win.location.href);
        if (!["http:", "https:"].includes(destination.protocol)) return;
        if (destination.hash && destination.origin === win.location.origin
          && destination.pathname === win.location.pathname && destination.search === win.location.search) return;
        // Keep the bridge alive while allowing the actual destination to open.
        event.preventDefault();
        event.stopPropagation();
        win.open(destination.href, "_blank", "noopener,noreferrer");
      };
      root.addEventListener("click", openLink, true);
      return () => root.removeEventListener("click", openLink, true);
    }
    const ids = new Set(sections.map((section) => section.id));
    let frame = 0;
    const elements = () => Array.from(root.querySelectorAll<HTMLElement>("[data-blockforge-block-id]"))
      .filter((element) => ids.has(element.dataset.blockforgeBlockId!) && findOwningSection(element, root, ids) === element);
    const nodes = elements();
    const byId = new Map(nodes.map((node) => [node.dataset.blockforgeBlockId, node]));
    if (previousOrderRef.current !== null && previousOrderRef.current !== sectionKey && activeBlockId) {
      byId.get(activeBlockId)?.scrollIntoView({ block: "nearest", behavior: "instant" });
    }
    previousOrderRef.current = sectionKey;
    const boxFor = (id: string | null): Box | null => {
      const element = id ? byId.get(id) : null;
      if (!element || !id) return null;
      const rect = element.getBoundingClientRect();
      if (rect.width <= 0 || rect.height <= 0 || rect.bottom <= 0 || rect.top >= win.innerHeight) return null;
      return { id, left: rect.left, top: rect.top, width: rect.width, height: rect.height };
    };
    const measure = () => {
      frame = 0;
      const selected = boxFor(activeBlockId);
      const hovered = boxFor(hoveredRef.current?.id ?? null);
      const boundaryBox = hovered ?? selected;
      const before = hovered ? hoveredRef.current?.before ?? false : false;
      const y = boundaryBox ? boundaryBox.top + (before ? 0 : boundaryBox.height) : -1;
      // Never pin an offscreen insertion point to a false viewport boundary.
      const boundary = boundaryBox && y >= 16 && y <= win.innerHeight - 16 ? { ...boundaryBox, before, top: y } : null;
      const next = { selected, hovered, boundary };
      setGeometry((previous) => JSON.stringify(previous) === JSON.stringify(next) ? previous : next);
    };
    const schedule = () => { if (!frame) frame = win.requestAnimationFrame(measure); };
    const hover = (event: PointerEvent) => {
      if (event.pointerType !== "mouse" && event.pointerType !== "pen") return;
      const target = event.target as Element;
      if (target.closest("[data-blockforge-preview-control]")) return;
      const owner = findOwningSection(target, root, ids);
      const rect = owner?.getBoundingClientRect();
      const id = owner?.dataset.blockforgeBlockId;
      if (id !== hoveredRef.current?.id) setDismissed(false);
      hoveredRef.current = id && rect ? { id, before: event.clientY - rect.top < Math.min(40, rect.height / 2) } : null;
      schedule();
    };
    const select = (event: MouseEvent) => {
      const target = event.target as Element;
      if (target.closest("[data-blockforge-preview-control]")) return;
      const owner = findOwningSection(target, root, ids);
      if (owner || target.closest("a,button,input,textarea,select,summary")) {
        event.preventDefault();
        event.stopPropagation();
      }
      if (owner?.dataset.blockforgeBlockId) {
        setDismissed(false);
        callbacks.current.onSelect(owner.dataset.blockforgeBlockId);
      }
    };
    const keydown = (event: KeyboardEvent) => {
      if (event.key === "Escape") { hoveredRef.current = null; setDismissed(true); return; }
      if (event.key !== "Enter" && event.key !== " ") return;
      const owner = findOwningSection(event.target as Element, root, ids);
      if (owner !== event.target) return;
      event.preventDefault();
      setDismissed(false);
      if (owner?.dataset.blockforgeBlockId) callbacks.current.onSelect(owner.dataset.blockforgeBlockId);
    };
    const focus = (event: FocusEvent) => {
      const owner = findOwningSection(event.target as Element, root, ids);
      if (!owner) return;
      setDismissed(false);
      hoveredRef.current = { id: owner.dataset.blockforgeBlockId!, before: false };
      schedule();
    };
    const leave = (event: PointerEvent) => {
      if ((event.relatedTarget as Element | null)?.closest?.("[data-blockforge-preview-control]")) return;
      hoveredRef.current = null; schedule();
    };
    const previousAttributes = nodes.map((node) => [node, node.getAttribute("tabindex"), node.getAttribute("aria-label"), node.getAttribute("role"), node.classList.contains("cursor-pointer")] as const);
    nodes.forEach((node) => {
      node.tabIndex = 0;
      node.setAttribute("role", "group");
      node.setAttribute("aria-label", `Select ${sectionLabel(sections.find((section) => section.id === node.dataset.blockforgeBlockId)!)} section`);
      node.classList.add("cursor-pointer");
    });
    const observer = new ResizeObserver(schedule);
    observer.observe(root);
    nodes.forEach((node) => observer.observe(node));
    root.addEventListener("pointermove", hover);
    root.addEventListener("pointerleave", leave);
    root.addEventListener("click", select, true);
    root.addEventListener("keydown", keydown);
    root.addEventListener("focusin", focus);
    root.addEventListener("load", schedule, true);
    win.addEventListener("scroll", schedule, true);
    win.addEventListener("resize", schedule);
    schedule();
    return () => {
      observer.disconnect(); win.cancelAnimationFrame(frame);
      root.removeEventListener("pointermove", hover); root.removeEventListener("pointerleave", leave);
      root.removeEventListener("click", select, true); root.removeEventListener("keydown", keydown);
      root.removeEventListener("focusin", focus); root.removeEventListener("load", schedule, true);
      win.removeEventListener("scroll", schedule, true); win.removeEventListener("resize", schedule);
      previousAttributes.forEach(([node, tabIndex, label, role, hadCursorClass]) => {
        if (tabIndex === null) node.removeAttribute("tabindex"); else node.setAttribute("tabindex", tabIndex);
        if (label === null) node.removeAttribute("aria-label"); else node.setAttribute("aria-label", label);
        if (role === null) node.removeAttribute("role"); else node.setAttribute("role", role);
        if (!hadCursorClass) node.classList.remove("cursor-pointer");
      });
    };
  }, [rootRef, documentKey, sectionKey, activeBlockId, browsing]);

  const selected = sections.find((section) => section.id === activeBlockId);
  const hovered = sections.find((section) => section.id === geometry.hovered?.id);
  const boundarySection = sections.find((section) => section.id === geometry.boundary?.id);
  const selectedIndex = sections.findIndex((section) => section.id === activeBlockId);
  const outline = (box: Box, active: boolean) => <div key={box.id} aria-hidden="true"
    className={`pointer-events-none fixed z-[2147483645] ${active ? "border-2 border-violet-600" : "border border-violet-400"}`}
    style={{ left: box.left, top: box.top, width: box.width, height: box.height }} />;
  return <>
    <div data-blockforge-preview-control className="fixed bottom-3 right-3 z-[2147483647] flex items-center gap-2 rounded-lg border border-slate-200 bg-white px-2 py-1 text-xs text-slate-700 shadow-sm">
      <span className="hidden sm:inline">{browsing ? "Links open in a new tab" : "Select a section to edit or move it"}</span>
      <button type="button" aria-pressed={browsing} onClick={() => { setBrowsing(!browsing); setDismissed(false); }}
        className="min-h-8 rounded-md px-2 font-bold text-violet-700 hover:bg-violet-50 focus-visible:ring-2 focus-visible:ring-violet-500">{browsing ? "Return to editing" : "Browse preview"}</button>
    </div>
    {!browsing && !dismissed && <>
      {geometry.selected && selected && geometry.selected.id === selected.id && outline(geometry.selected, true)}
      {geometry.hovered && hovered && geometry.hovered.id !== activeBlockId && outline(geometry.hovered, false)}
      {geometry.hovered && hovered && geometry.hovered.id !== activeBlockId && <span aria-hidden="true"
        className="pointer-events-none fixed z-[2147483646] rounded bg-violet-600 px-2 py-1 text-xs font-bold text-white"
        style={{ left: geometry.hovered.left + 4, top: Math.max(0, geometry.hovered.top) }}>{sectionLabel(hovered)}</span>}
      {canAct && geometry.selected && selected && geometry.selected.id === selected.id && <div className="fixed z-[2147483646] max-w-[calc(100vw-16px)]"
        style={{ left: Math.max(8, geometry.selected.left), top: Math.max(4, geometry.selected.top - 44), maxWidth: `calc(100vw - ${Math.max(8, geometry.selected.left) + 8}px)` }}>
        <SectionToolbar key={selected.id} label={sectionLabel(selected)} isFirst={selectedIndex === 0} isLast={selectedIndex === sections.length - 1}
          onDismiss={() => {
            Array.from(rootRef.current?.querySelectorAll<HTMLElement>("[data-blockforge-block-id]") ?? []).find((node) => node.dataset.blockforgeBlockId === selected.id)?.focus({ preventScroll: true });
            setDismissed(true);
          }} onAction={(action) => callbacks.current.onAction(selected.id, action)} />
      </div>}
      {geometry.boundary && boundarySection && <div className="fixed z-[2147483647] -translate-y-1/2"
        style={{ left: geometry.boundary.left, top: geometry.boundary.top, width: geometry.boundary.width }}>
        <SectionInsertionBoundary label={`Add section ${geometry.boundary.before ? "before" : "after"} ${sectionLabel(boundarySection)}`}
          onInsert={() => {
            const boundary = geometry.boundary!;
            if (boundary.before && canAct) callbacks.current.onAction(boundary.id, "insert-before");
            else callbacks.current.onInsert(boundary.before
              ? { atIndex: sections.findIndex((section) => section.id === boundary.id) } : { afterBlockId: boundary.id });
          }} />
      </div>}
      {sections.length === 0 && <div className="fixed left-6 right-6 top-1/2 z-[2147483646] rounded-xl bg-white p-6 text-center shadow-lg">
        <p className="mb-4 text-sm font-semibold text-slate-700">Add your first section</p>
        <SectionInsertionBoundary label="Add first section" onInsert={() => callbacks.current.onInsert({ atIndex: 0 })} />
      </div>}
    </>}
  </>;
}
